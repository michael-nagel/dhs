# README and Guidance

## Overview

The code files in this replication package construct the output in Nagel et al. (2024) using Python and Miniconda. The `__main__.py` file runs all the code to generate the 5 figures and 4 tables. A replicator should expect the code to run for approximately 10 days. See the [documentation](http://localhost:52330/docs/_build/html/index.html) for detailed information on the underlying code.

## Data Availability and Provenance Statements

### Statement about Rights

- [x] I certify that the author(s) of the manuscript have legitimate access to and permission to use the data used in this manuscript.

- [ ] I certify that the author(s) of the manuscript have documented permission to redistribute/publish the data contained within this replication package. Appropriate permission are documented in the [LICENSE] file.

### Summary of Availability

- [x] All data **are** publicly available.

- [ ] Some data **cannot be made** publicly available.

- [ ] **No data can be made** publicly available.

  | Data.Name      | Data.Files   | Location | Provided | Citation |
  | -------------- | ------------ | -------- | -------- | -------- |
  | "Alcohol Data" | alc_data.pkl | Data/    | TRUE     |          |

### Alcohol Data

The data used in this manuscript originates from Fischer et al. (2023, available at [SSRN](http://dx.doi.org/10.2139/ssrn.4569227)), which is the first paper stemming from our joint project funded by the Deutsche Forschungsgemeinschaft (DFG, German Research Foundation) under Germany's Excellence Strategy - EXC number 2064/1 - Project number 390727645

Datafiles:

- `Data/alc_data.pkl`

## Dataset List

A detailed description of the data files' variables (long-form names, data type and description) in tablular form is provided in the codebook, which is part of this repository.

## Computational Requirements

Please strictly follow the steps outlined below to properly set up the project and environment required for replication. A Linux distribution (e.g., Ubuntu) or WSL is required to run the code.

    conda create --name dhs_env --file conda-linux-64.lock
    export PYTHONNOUSERSITE=1
    conda activate dhs_env
    poetry install

In some cases, you might run the line below before the above code block.

    sudo apt install python-is-python3

### Controlled Randomness

The random seed is set in the configuration file `conf/config.yaml` where basic variables for all scripts are defined. If you want to change the random seed, use `conf/general/alt_seed.yaml`.

### Memory and Runtime Requirements

#### Summary

Approximate time needed to reproduce the analyses on a standard (2023) desktop machine:

- [ ] \<10 minutes

- [ ] 10-60 minutes

- [ ] 1-2 hours

- [ ] 2-8 hours

- [ ] 8-24 hours

- [ ] 1-3 days

- [x] 3-14 days

- [ ] \> 14 days

- [ ] Not feasible to run on a desktop machine, as described below.

#### Details

The code was last executed on a machine with the following features # TODO Update after run

- Linux distribution: openSUSE Leap 15.0

- OS type: 64-bit

- 16 x AMD EPYC Processor (with IBPB)

- 31.4 GB RAM
