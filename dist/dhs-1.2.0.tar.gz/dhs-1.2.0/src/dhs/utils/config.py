# !/usr/bin/env python3
# -*- coding: utf-8 -*-

# %% Imports

from dataclasses import dataclass

# %% Classes


@dataclass
class Paths:
    acc: str
    figures: str
    tables: str
    data: str
    models: str


@dataclass
class Files:
    clr_plt: str


@dataclass
class General:
    seed: int
    priors: list
    n_repl: int
    save: bool
    main_scripts: list


@dataclass
class Densities:
    samples: int
    n_obs: int
    dim: int
    noise: float
    trunc: float
    seq: list


@dataclass
class Simul1:
    dim: int
    spars_lev: list
    sig_stren: list


@dataclass
class Simul2:
    n_obs: list
    n_vars: int
    frac_rel_vars: float
    feat_corr: list


@dataclass
class Hyperparams:
    spars_lev: float
    conc_rate: list


@dataclass
class Estimation:
    hdi: float
    n_chains: int
    n_draws: int
    n_tune: int
    targ_acpt: float


@dataclass
class Plotting:
    base_siz: float
    leg_mkr_siz: float
    line_width: float
    mkr_siz: float
    ax_line_width: float
    xtick_maj_width: float
    ytick_maj_width: float
    xtick_maj_siz: float
    ytick_maj_siz: float
    font_family: str


@dataclass
class Example:
    hdi: float
    n_draws: int
    n_tune: int
    n_chains: int
    targ_acpt: float


@dataclass
class DHSConfig:
    paths: Paths
    files: Files
    general: General
    densities: Densities
    first_simul: Simul1
    second_simul: Simul2
    hyperparams: Hyperparams
    estimation: Estimation
    plotting: Plotting
    example: Example
