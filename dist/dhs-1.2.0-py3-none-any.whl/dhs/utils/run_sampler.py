#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# %% Imports

import arviz as az
import pymc as pm
import pymc.sampling_jax as pmjax

# %% Function


def run_sampler(
    model: pm.Model,
    n_draws: int,
    n_tune: int,
    n_chains: int,
    seed: int,
    targ_acpt: float,
    *args,
    **kwargs,
) -> az.InferenceData:
    """
    Run the sampler.

    This function numerically estimates the defined PyMC model
    using Hamiltonian Monte Carlo methods (NUTS). The output
    (trace) object keeps track of the sampled values of each
    variable over the course of the sampling process and can be
    used to calculate summary statistics, to draw posterior
    distributions, and to diagnose convergence, for example.

    Parameters
    ----------
    model : pm.Model
        PyMC model to be estimated.
    n_draws : int
        Number of draws.
    n_tune : int
        Number of tuning samples (burn-in).
    n_chains : int
        Number of chains.
    seed : int
        Random seed.
    targ_acpt : float
        Target acceptance rate.
    *args : non-keyword arguments
        Parameters specific to the trace.
    **kwargs : keyword arguments
        Parameters specific to the trace.

    Returns
    -------
    arviz.InferenceData
        Record of the sampling process.
    """
    with model:
        trace = pmjax.sample_numpyro_nuts(
            model=model,
            draws=n_draws,
            tune=n_tune,
            chains=n_chains,
            random_seed=seed,
            target_accept=targ_acpt,
            *args,
            **kwargs,
        )

    return trace
