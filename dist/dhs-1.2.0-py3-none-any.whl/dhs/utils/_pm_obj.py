#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import pymc as pm

# %% Class


class _PmObj:
    def __init__(self) -> None:
        pass

    @staticmethod
    def create_normal(
        mu: int | float = 0, sigma: int | float = 1, *args, **kwargs
    ) -> pm.Distribution:
        """
        Create normal prior.

        Parameters
        ----------
        mu : int | float, default 0
            First Normal parameter.
        sigma : int | float, default 1
            second Normal parameter.
        *args : non-keyword arguments
            Parameters specific to the chosen distribution.
        **kwargs : keyword arguments
            Parameters specific to the chosen distribution.

        Returns
        -------
        distribution : pm.Distribution
            PyMC Distribution representing the specified distribution.
        """
        return pm.Normal(mu=mu, sigma=sigma, *args, **kwargs)

    @staticmethod
    def create_laplace(
        mu: int | float = 0, b: int | float = 1, *args, **kwargs
    ) -> pm.Distribution:
        """
        Create Laplace prior.

        Parameters
        ----------
        mu : int | float, default 0
            First Laplace parameter.
        b : int | float, default 1
            Second Laplace parameter.
        *args : non-keyword arguments
            Parameters specific to the chosen distribution.
        **kwargs : keyword arguments
            Parameters specific to the chosen distribution.

        Returns
        -------
        distribution : pm.Distribution
            PyMC Distribution representing the specified distribution.
        """
        return pm.Laplace(mu=mu, b=b, *args, **kwargs)

    @staticmethod
    def create_halfnormal(
        sigma: int | float = 1, *args, **kwargs
    ) -> pm.Distribution:
        """
        Create normal prior.

        Parameters
        ----------
        sigma : int | float, default 1
            HalfNormal parameter.
        *args : non-keyword arguments
            Parameters specific to the chosen distribution.
        **kwargs : keyword arguments
            Parameters specific to the chosen distribution.

        Returns
        -------
        distribution : pm.Distribution
            PyMC Distribution representing the specified distribution.
        """
        return pm.HalfNormal(sigma=sigma, *args, **kwargs)

    @staticmethod
    def create_halfcauchy(
        beta: int | float = 1, *args, **kwargs
    ) -> pm.Distribution:
        """
        Create Half-Cauchy prior.

        Parameters
        ----------
        beta : int | float, default 1
            HalfCauchy parameter.
        *args : non-keyword arguments
            Parameters specific to the chosen distribution.
        **kwargs : keyword arguments
            Parameters specific to the chosen distribution.

        Returns
        -------
        distribution : pm.Distribution
            PyMC Distribution representing the specified distribution.
        """
        return pm.HalfCauchy(beta=beta, *args, **kwargs)

    @staticmethod
    def create_beta(
        alpha: int | float = 2, beta: int | float = 8, *args, **kwargs
    ) -> pm.Distribution:
        """
        Create beta prior.

        Parameters
        ----------
        alpha : int | float, default 2
            First Beta parameter.
        beta : int | float, default 8
            Second Beta parameter.
        *args : non-keyword arguments
            Parameters specific to the chosen distribution.
        **kwargs : keyword arguments
            Parameters specific to the chosen distribution.

        Returns
        -------
        distribution : pm.Distribution
            PyMC Distribution representing the specified distribution.
        """
        return pm.Beta(alpha=alpha, beta=beta, *args, **kwargs)

    @staticmethod
    def create_dirichlet(
        comp: int, concen, *args, **kwargs
    ) -> pm.Distribution:
        """
        Create Dirichlet prior.

        Parameters
        ----------
        comp : int
            Determines the number of components of the Dirichlet.
        concen :
            Concentration rate.
        *args : non-keyword arguments
            Parameters specific to the chosen distribution.
        **kwargs : keyword arguments
            Parameters specific to the chosen distribution.

        Returns
        -------
        distribution : pm.Distribution
            PyMC Distribution representing the specified distribution.
        """
        return pm.Dirichlet(a=np.ones(comp) * concen, *args, **kwargs)

    @staticmethod
    def create_gamma(
        alpha: int | float, beta: int | float, *args, **kwargs
    ) -> pm.Distribution:
        """
        Create gamma prior.

        Parameters
        ----------
        alpha : int | float
            First Gamma parameter
        beta : int | float
            Second Gamma parameter
        *args : non-keyword arguments
            Parameters specific to the chosen distribution.
        **kwargs : keyword arguments
            Parameters specific to the chosen distribution.

        Returns
        -------
        distribution : pm.Distribution
            PyMC Distribution representing the specified distribution.
        """
        return pm.Gamma(alpha=alpha, beta=beta, *args, **kwargs)

    @staticmethod
    def create_invgamma(
        alpha: int | float = 1, beta: int | float = 4, *args, **kwargs
    ) -> pm.Distribution:
        """
        Create inverse gamma prior.

        Parameters
        ----------
        alpha : int | float, default 1
            First Inverse Gamma parameter.
        beta : int | float, default 4
            Second Inverse Gamma parameter.
        *args : non-keyword arguments
            Parameters specific to the chosen distribution.
        **kwargs : keyword arguments
            Parameters specific to the chosen distribution.

        Returns
        -------
        distribution : pm.Distribution
            PyMC Distribution representing the specified distribution.
        """
        return pm.InverseGamma(alpha=alpha, beta=beta, *args, **kwargs)
